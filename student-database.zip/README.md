# 🗂 Student Database Management System

A simple Python CLI app for managing student data using SQLite.

## 🚀 Features
- Add new students
- View all student records
- Search students by name

## 🛠 Technologies
- Python
- SQLite (Built-in with Python)

## ▶️ How to Run
```bash
python main.py
```

## 📂 Project Type
Beginner-level database project for school/college students.

## 🧠 Concepts Used
- Database (SQLite)
- SQL queries
- Python functions & control flow

## 📜 License
MIT License
