import sqlite3

# Connect to database (or create it)
conn = sqlite3.connect("students.db")
cursor = conn.cursor()

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    age INTEGER,
    grade TEXT
)
""")

# Add a student
def add_student(name, age, grade):
    cursor.execute("INSERT INTO students (name, age, grade) VALUES (?, ?, ?)", (name, age, grade))
    conn.commit()
    print("Student added successfully.")

# View all students
def view_students():
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

# Search student by name
def search_student(name):
    cursor.execute("SELECT * FROM students WHERE name = ?", (name,))
    rows = cursor.fetchall()
    for row in rows:
        print(row)

# CLI menu
def menu():
    while True:
        print("\nStudent Database Menu")
        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            name = input("Name: ")
            age = int(input("Age: "))
            grade = input("Grade: ")
            add_student(name, age, grade)
        elif choice == "2":
            view_students()
        elif choice == "3":
            name = input("Enter name to search: ")
            search_student(name)
        elif choice == "4":
            break
        else:
            print("Invalid choice.")

menu()
conn.close()
